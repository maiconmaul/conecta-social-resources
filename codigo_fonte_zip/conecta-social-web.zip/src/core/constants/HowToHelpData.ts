export const howToHelpData = [
  {
    src: "/images/howtohelp3.png",
    alt: "Doe Recursos",
    title: "Doe Recursos",
    description:
      "Contribua financeiramente para que possamos fornecer materiais escolares, alimentação e suporte básico para as crianças. Cada doação ajuda a construir um futuro melhor.",
  },
  {
    src: "/images/howtohelp2.png",
    alt: "Seja Voluntário",
    title: "Seja Voluntário",
    description:
      "Compartilhe seu tempo e suas habilidades. Seja como mentor, professor ou organizador de eventos, sua ajuda é essencial para transformar vidas.",
  },
  {
    src: "/images/howtohelp1.png",
    alt: "Divulgue o Projeto",
    title: "Divulgue o Projeto",
    description:
      "Ajude-nos a alcançar mais pessoas! Compartilhe nosso projeto nas redes sociais e faça parte dessa corrente de solidariedade.",
  },
];

export default howToHelpData;
