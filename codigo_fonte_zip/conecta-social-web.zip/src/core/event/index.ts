import { eventSchema } from './validation/eventSchema';
import { IEvent } from './model/IEvent';

export type { IEvent };
export { eventSchema };
