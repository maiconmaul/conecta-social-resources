import { IVolunteer } from './model/IVolunteer';

export type { IVolunteer };
