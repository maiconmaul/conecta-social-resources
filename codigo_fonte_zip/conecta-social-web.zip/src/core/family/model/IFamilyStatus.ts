export enum FamilyStatus {
   ATIVO = 'ATIVO',
   CANCELADO = 'CANCELADO',
}
