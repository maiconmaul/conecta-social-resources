export enum EmployeeRole {
  ADMIN = 'ADMIN',
  MANAGER = 'MANAGER',
  VOLUNTEER = 'VOLUNTEER',
}
