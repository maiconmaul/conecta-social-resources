-- AlterTable
ALTER TABLE "events" ALTER COLUMN "embedded_instagram" SET DATA TYPE TEXT;
